const bcrypt = require("bcrypt");
const { User } = require("../models");
const { Op } = require("sequelize");
const { getError } = require("../configurations/error500");

exports.getAllUsers = async (req, res, next) => {
  try {
    const users = await User.findAll();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json(getError(error));
  }
};

exports.signup = async (req, res, next) => {
  try {
    const user = await User.findOne({
      where: {
        [Op.or]: [{ email: req.body.login }, { username: req.body.login }],
      },
    });
    if (user) return res.status(400).json({ error: "User already exist!" });

    user = await User.create(
      {
        ...res.body,
      },
      {
        fields: ["username", "email", "password"],
      }
    );
    res.status(200).json({ message: "Compte crée avec succès" });
  } catch (error) {
    res.status(500).json(getError(error));
  }
};

exports.login = async (req, res, next) => {
  try {
    const user = await User.findOne({
      where: {
        [Op.or]: [{ email: req.body.login }, { username: req.body.login }],
        type: 0,
      },
    });
    if (!user) return res.status(401).json({ error: "Utilisateur non trouvé" });

    const isPasswordValid = await bcrypt.compare(
      req.body.password,
      user.password
    );

    if (!isPasswordValid)
      return res.status(401).json({ error: "Mot de passe incorrect" });

    res.status(200).json({ message: "Connecté avec succès" });
  } catch (error) {
    res.status(500).json(getError(error));
  }
};
