const { DataTypes } = require("sequelize");
const bcrypt = require("bcrypt");

const userSchema = {
  idUser: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },

  username: {
    type: DataTypes.STRING,
    unique: {
      args: true,
      msg: "Nom d'utilisateur déjà utilisé!",
    },
    allowNull: false,

    validate: {
      isAlphanumeric: {
        args: true,
        msg: "Nom d'utilisateur doit être de type Alphanumérique",
      },
      notNull: {
        args: false,
        msg: "Username cannot be nul",
      },
    },
  },

  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: {
      args: true,
      msg: "Email déjà utilisé!",
    },
    validate: {
      isEmail: {
        args: true,
        msg: "It's not a valid email",
      },
      notNull: {
        args: false,
        msg: "Email cannot be nul",
      },
    },
  },

  password: {
    type: DataTypes.STRING,
    allowNull: false,

    set(value) {
      this.setDataValue("password", bcrypt.hashSync(value, 10));
    },
  },

  type: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
    validate: {
      isIn: [[0, 1]], // ["User", "Administrator"]
    },
  },
};

module.exports = userSchema;
