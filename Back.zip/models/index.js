const userSchema = require("./User");
const sequelize = require("../configurations/Sequelize");

exports.User = sequelize.define("User", userSchema);
