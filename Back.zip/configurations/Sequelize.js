const { Sequelize } = require("sequelize");

// Récupération des données sensibes
const USER_ID = process.env.USER_ID;
const USER_KEY = process.env.USER_KEY;
const DB_NAME = process.env.DB_NAME;
const HOST_NAME = process.env.HOST_NAME;
const DIALECT = process.env.DIALECT;

console.log(USER_ID);

const sequelize = new Sequelize(DB_NAME, USER_ID, USER_KEY, {
  dialect: DIALECT,
  host: HOST_NAME,
});

try {
  sequelize.authenticate();
  console.log("Connection has been established successfully.");
} catch (error) {
  console.error("Unable to connect to the database:", error);
}

(async () => {
  await sequelize
    .sync({ force: false })
    .then((res) => console.log("Tables created successfully"))
    .catch((err) => console.log(err));
})();

module.exports = sequelize;
