exports.getError = (error, defaultMessage) => {
  console.log(error);
  message = defaultMessage || "Erreur server";
  let hasOwnPropertyError = Object.prototype.hasOwnProperty.call(
    error,
    "errors"
  );
  if (hasOwnPropertyError) {
    if (error.errors.length > 0) {
      let hasOwnPropertyMessage = Object.prototype.hasOwnProperty.call(
        error.errors[0],
        "message"
      );
      if (hasOwnPropertyMessage) message = error.errors[0].message;
    }
  }

  hasOwnPropertyError = Object.prototype.hasOwnProperty.call(error, "message");
  if (hasOwnPropertyError) message = error.message;
  return { error: message };
};
