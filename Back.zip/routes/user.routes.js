const express = require("express");
const router = express.Router();

const userCtrl = require("../controlers/user.controlers");

router.get("/", userCtrl.getAllUsers);
router.post("/login", userCtrl.login);
router.post("/signup", userCtrl.signup);

module.exports = router;
