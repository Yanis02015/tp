export default function Dashboard() {
  return <div>test</div>;
}
