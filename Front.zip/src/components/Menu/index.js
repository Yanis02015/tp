import { Link } from "react-router-dom";
import "./style.css";
export default function Menu() {
  return (
    <header className="d-flex justify-content-between pt-3">
      <h3 className="masthead-brand">Yanis.dev</h3>
      <nav className="nav nav-masthead justify-content-center">
        <Link className="nav-link active" to="/">
          Home
        </Link>
        <Link className="nav-link" to="/login">
          Login
        </Link>
        <Link className="nav-link" to="/about">
          About
        </Link>
      </nav>
    </header>
  );
}
