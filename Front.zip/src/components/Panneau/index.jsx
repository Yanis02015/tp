import { useState } from "react";

export default function Panneau() {
  const [value, setValue] = useState(1);
  const handleChange = (evt) => {
    setValue(evt.target.value);
  };
  return (
    <>
      <div>
        <div className="mt-5" />
        <h2>Slider :</h2>
        <label htmlFor="customRange1" className="form-label">
          range : <strong className="text-primary">{value}</strong>
        </label>
        <input
          type="range"
          className="form-range"
          id="customRange1"
          value={value}
          onChange={handleChange}
        ></input>
      </div>
    </>
  );
}
