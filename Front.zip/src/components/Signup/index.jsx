import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./style.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const login = async (event) => {
    event.preventDefault();
    axios({
      method: "post",
      url: "http://localhost:3000/api/user/login",
      data: {
        login: email,
        password: password,
      },
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });
  };

  const handleEmail = (event) => {
    setEmail(event.target.value);
  };

  const handlePassword = (event) => {
    setPassword(event.target.value);
  };

  return (
    <>
      <Link to="/" className="position-absolute text-black ml-3">
        &larr; Back to home
      </Link>
      <div className="login-container">
        <form onSubmit={login} className="form-signin">
          <img
            className="mb-4"
            src="https://i.ibb.co/Fbcq1zC/yanis-logo.png"
            alt=""
            width="72"
          />
          <h1 className="h3 mb-3 font-weight-normal">Please sign in</h1>
          <label for="inputEmail" className="sr-only">
            Email address
          </label>
          <input
            type="email"
            id="inputEmail"
            className="form-control"
            placeholder="Email address"
            onChange={handleEmail}
            required
            autofocus
          />
          <label for="inputPassword" className="sr-only">
            Password
          </label>
          <input
            type="password"
            id="inputPassword"
            onChange={handlePassword}
            className="form-control"
            placeholder="Password"
            required
          />
          <div className="checkbox mb-3">
            <label>
              <input type="checkbox" value="remember-me" /> Remember me
            </label>
          </div>
          <button
            className="btn btn-lg btn-primary btn-block text-white"
            type="submit"
          >
            Sign in
          </button>
          <Link to="/login">J'ai déjà un compte</Link>
          <p className="mt-5 mb-3 text-muted">&copy; 2017-2018</p>
        </form>
      </div>
    </>
  );
}
