export default function Card({ url, title, description }) {
  return (
    <>
      <div
        className="card m-auto"
        style={{ flexGrow: 1, overflow: "hidden", width: 300 }}
      >
        <img className="card-img-top" src={url} alt={description} />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{description}</p>
          <a
            href={url}
            target="_blank"
            className="btn btn-primary text-secondary"
            rel="noreferrer"
          >
            Show
          </a>
        </div>
      </div>
    </>
  );
}
