export default function Home() {
  return (
    <div className="pt-5">
      <h1>Yo les bg comment ça va ?</h1>
      <div>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vel
        repellendus, quasi quam ea deserunt veniam asperiores corporis, error
        sit itaque eius molestias explicabo voluptatibus? Repellat accusamus
        esse nostrum hic mollitia!
      </div>
    </div>
  );
}
