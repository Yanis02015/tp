import Home from "./components/Home";
import Menu from "./components/Menu";
import Panneau from "./components/Panneau";
import ListeBouquets from "./components/ListeBouquets";

function App() {
  return (
    <div className="container">
      <Menu />
      <Home />
      <Panneau />
      <ListeBouquets />
    </div>
  );
}

export default App;
